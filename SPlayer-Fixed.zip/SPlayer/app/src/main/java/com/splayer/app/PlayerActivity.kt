package com.splayer.app

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.MoreExecutors

class PlayerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_URI = "video_uri"
        const val EXTRA_TITLE = "video_title"
    }

    private var controller: MediaController? = null
    private lateinit var playerView: PlayerView
    private lateinit var audioButton: Button
    private lateinit var status: TextView
    private var audioOnly = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        status = TextView(this).apply {
            text = intent.getStringExtra(EXTRA_TITLE) ?: "S Player"
            setTextColor(android.graphics.Color.WHITE)
            textSize = 15f
            setPadding(16, 12, 16, 12)
        }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 18)
        }
        audioButton = Button(this).apply {
            text = "Audio only"
            setOnClickListener { toggleAudioOnly() }
        }
        val speedButton = Button(this).apply {
            text = "Speed 1x"
            setOnClickListener {
                val p = controller ?: return@setOnClickListener
                val next = if (p.playbackParameters.speed >= 1.95f) 0.5f else when {
                    p.playbackParameters.speed < 0.75f -> 1f
                    p.playbackParameters.speed < 1.25f -> 1.25f
                    p.playbackParameters.speed < 1.5f -> 1.5f
                    else -> 2f
                }
                p.setPlaybackSpeed(next)
                text = "Speed ${next}x"
            }
        }
        controls.addView(audioButton)
        controls.addView(speedButton)
        root.addView(status)
        root.addView(playerView)
        root.addView(controls)
        setContentView(root)

        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            controller = future.get()
            playerView.player = controller
            val uri = intent.getStringExtra(EXTRA_URI)?.let(Uri::parse)
            if (uri != null) {
                controller?.setMediaItem(MediaItem.fromUri(uri))
                controller?.prepare()
                controller?.play()
            }
        }, MoreExecutors.directExecutor())
    }

    private fun toggleAudioOnly() {
        audioOnly = !audioOnly
        playerView.visibility = if (audioOnly) View.GONE else View.VISIBLE
        audioButton.text = if (audioOnly) "Show video" else "Audio only"
        status.text = if (audioOnly) "Audio mode • playback continues with screen off" else (intent.getStringExtra(EXTRA_TITLE) ?: "S Player")
    }

    override fun onStop() {
        super.onStop()
        // Playback is owned by PlaybackService, so it can continue after this screen is left.
    }

    override fun onDestroy() {
        playerView.player = null
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
