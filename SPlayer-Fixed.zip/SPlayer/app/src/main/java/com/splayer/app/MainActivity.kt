package com.splayer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

data class LocalVideo(val uri: Uri, val title: String, val duration: Long, val size: Long)

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private val requestCode = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 7, 17)
        window.navigationBarColor = android.graphics.Color.rgb(9, 7, 17)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 16)
            setBackgroundColor(android.graphics.Color.rgb(9, 7, 17))
        }
        val heading = TextView(this).apply {
            text = "S Player"
            textSize = 30f
            setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "Your videos"
            textSize = 14f
            setTextColor(0xFFB9A9D0.toInt())
            setPadding(0, 4, 0, 18)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(heading)
        root.addView(sub)
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (hasVideoPermission()) loadVideos() else requestVideoPermission()
    }

    private fun hasVideoPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestVideoPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(permission), requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadVideos()
        else Toast.makeText(this, "Allow video access to show your local videos.", Toast.LENGTH_LONG).show()
    }

    private fun loadVideos() {
        list.removeAllViews()
        val videos = mutableListOf<LocalVideo>()
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                         else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE
        )
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        contentResolver.query(collection, projection, null, null, sort)?.use { c: Cursor ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                videos.add(LocalVideo(
                    Uri.withAppendedPath(collection, id.toString()),
                    c.getString(nameCol) ?: "Video",
                    c.getLong(durationCol),
                    c.getLong(sizeCol)
                ))
            }
        }
        if (videos.isEmpty()) {
            list.addView(label("No videos found on this device.", 16f, 0xFFB9A9D0.toInt()))
            return
        }
        videos.forEach { video ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 14, 14, 14)
                setBackgroundColor(0xFF1B1626.toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                        putExtra(PlayerActivity.EXTRA_URI, video.uri.toString())
                        putExtra(PlayerActivity.EXTRA_TITLE, video.title)
                    })
                }
            }
            row.addView(label(video.title, 16f, android.graphics.Color.WHITE))
            row.addView(label("${formatTime(video.duration)}  •  ${formatSize(video.size)}", 12f, 0xFFB9A9D0.toInt()))
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
            list.addView(row, lp)
        }
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color); setPadding(0, 2, 0, 2)
    }

    private fun formatTime(ms: Long): String {
        val sec = ms / 1000
        return "%d:%02d".format(sec / 60, sec % 60)
    }
    private fun formatSize(bytes: Long): String = "%.1f MB".format(bytes / (1024f * 1024f))
}
