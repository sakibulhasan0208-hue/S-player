# S Player — Android starter project

This is the first runnable source-project draft for S Player.

## Included in this alpha
- Local device video listing using Android MediaStore
- Playback through AndroidX Media3 / ExoPlayer
- MediaSessionService for background media playback and system media controls
- Audio-only screen mode (hides video while audio continues)
- Playback speed cycle (0.5x, 1x, 1.25x, 1.5x, 2x)
- Dark purple/black starter theme

## Open and build
1. Install Android Studio (latest stable) on a computer.
2. Open this `SPlayer` folder in Android Studio.
3. Let Gradle sync and install any requested Android SDK Platform 35 / Build Tools.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run. To make an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important alpha notes
- This is source code, not a prebuilt APK. This environment does not have Android SDK/Gradle installed, so it cannot compile or test an APK here.
- The first draft uses standard Media3 controls. Custom VLC-like gestures, thumbnail grid, subtitle picker, folder browsing, lock-screen verification, and polish are planned for the next iterations.
- Background audio behavior should be tested on the target phone; Android battery/background restrictions vary by manufacturer.
- App requests access only to the device's video library; it does not upload videos or use online video sources.
